/* Design by:
             Armando T. Saguin Jr. BSCS, MSIT
			 saguin.armando.jr@gmail.com
			 09087016820
*/

public class FileHandling
 {
//--------------------------------------------------------------------------------------------------------
//-----------------------------Main Program--------------------------------------------------------------
     public static void main(String args[])
         {
           MyWindow app = new MyWindow();
           app.setResizable(false);
           app.setLocation(400,250);
           
        }
}